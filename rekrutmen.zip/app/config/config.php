<?php 

define('BASEURL', "http://localhost/rekrutmen/");
define('DB_HOST' , 'localhost');
define('DB_USER' , 'root');
define('DB_PASS' , '');
define('DB_NAME' , 'rekrutmen');
define('ALLOWED_IMAGES_EXT' , ['jpg','jpeg','png','webp']);