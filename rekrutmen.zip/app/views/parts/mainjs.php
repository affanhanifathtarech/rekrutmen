<script src="public/assets/jquery/jquery-3.6.0.min.js"></script>
<script src="public/assets/bootstrap/bootstrap.bundle.min.js"></script>