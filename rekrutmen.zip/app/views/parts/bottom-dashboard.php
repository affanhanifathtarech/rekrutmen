</div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer text-center">
    <!-- Default to the left -->
    <strong>LDK KARISMA &copy; 2021</strong>. All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->